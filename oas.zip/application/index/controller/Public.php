<?php

namespace app\index\controller;

use app\common\controller\Frontend;
class Public extends Frontend
{
    public function upload(){
        $file = request()->file('image');
        if($file){
            $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
            if($info){
                return $info->getExtension();
            }else{
                // 上传失败获取错误信息
                return $file->getError();
            }
        }
    }
}