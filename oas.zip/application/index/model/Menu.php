<?php

namespace app\index\model;
use think\Model;
use fast\Tree;
class Menu extends Model
{
    public function  personnel_menu($where=[]){
        $where_menu['enable']="1";
        $where_menu['show']="1";
        $menu=$this->where($where_menu)->select();
        Tree::instance()->init($menu);
        $list=Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'title');
        foreach($list as $key=>$va){
            $find=db('group')->where($where)->where('FIND_IN_SET(:id,rules)',['id'=>$va['id']])->find();
            if($find){
                $select=true;
            }else{
                $select=false;
            }
            $list[$key]['select']=$select;
        }
        return $list;
    }
}