<?php

namespace app\index\model;
use think\Model;

class Group extends Model
{

}