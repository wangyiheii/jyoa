<?php

return [
    'autoload' => false,
    'hooks' => [],
    'route' => [],
    'priority' => [],
];
